Mr Malhotra — Android Studio source project

यह Android app का source project है; यह अभी तैयार APK नहीं है।

APK बनाने के लिए:
1. Android Studio को कंप्यूटर पर इंस्टॉल करें।
2. Android Studio में इस ZIP को extract करके बनी MrMalhotra_Android_Project फ़ोल्डर को Open करें।
3. Gradle sync पूरा होने दें। Android SDK Platform 35 मांगे तो Android Studio के SDK Manager से इंस्टॉल करें।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK आमतौर पर app/build/outputs/apk/debug/app-debug.apk में बनेगा।
6. APK अपने फोन में भेजकर इंस्टॉल करें। फोन पर unknown apps install की अनुमति देनी पड़ सकती है।

इस ऐप में मौजूदा HTML prototype Android WebView में चलता है। वीडियो/फाइल चुनने की सुविधा जोड़ी गई है।
महत्वपूर्ण सीमाएँ:
- प्रोफाइल, वीडियो सूची और पॉइंट्स अभी इसी डिवाइस पर स्थानीय demo data हैं।
- अभी ऑनलाइन अकाउंट, सर्वर, सभी उपयोगकर्ताओं के लिए साझा वीडियो, वास्तविक विज्ञापन नेटवर्क,
  वास्तविक पैसे/निकासी, या मालिक का ऑनलाइन Admin Dashboard नहीं है।
- Demo points वास्तविक पैसे नहीं हैं। विज्ञापन देखकर पैसे देने के लिए ad network की नीतियों
  और सुरक्षित backend की जरूरत होगी।
- ऐप के source code और signing key को अपने पास सुरक्षित रखें। अपने नाम से Play Store पर
  प्रकाशित करने के लिए आपका अपना Google Play Console खाता चाहिए।

अगर आपके पास केवल मोबाइल है और कंप्यूटर नहीं, तो इस source project से APK बनाना कठिन हो सकता है;
मैं मोबाइल पर उपलब्ध विकल्पों के लिए अलग-अलग कदम बता सकता हूँ।

ऑनलाइन APK बिल्ड (GitHub Actions):
1. पूरा प्रोजेक्ट (ZIP extract करने के बाद अंदर की फाइलें/फ़ोल्डर) अपने GitHub repository की main branch में अपलोड करें।
2. .github/workflows/android-apk.yml फाइल भी अपलोड होनी चाहिए।
3. GitHub में Actions टैब खोलें और "Build Mr Malhotra APK" workflow चुनें।
4. "Run workflow" दबाएँ, या main branch में फाइलें commit करने पर build अपने आप शुरू हो सकता है।
5. सफल build के बाद workflow run में Artifacts सेक्शन से Mr-Malhotra-debug-APK डाउनलोड करें।
6. ZIP artifact खोलें; उसके अंदर app-debug.apk होगा।

ध्यान दें: GitHub repository Private रखना बेहतर है। Public repository में आपका source code सबको दिख सकता है।
